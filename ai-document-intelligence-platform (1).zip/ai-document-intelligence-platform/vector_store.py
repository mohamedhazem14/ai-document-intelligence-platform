"""FAISS vector store helpers (local, CPU-only)."""
import os
import shutil

from langchain_community.vectorstores import FAISS
from langchain_core.documents import Document
from langchain_huggingface import HuggingFaceEmbeddings

from config import DB_DIR, EMBEDDING_MODEL, FAISS_INDEX_PATH


def get_embeddings_model() -> HuggingFaceEmbeddings:
    return HuggingFaceEmbeddings(
        model_name=EMBEDDING_MODEL,
        model_kwargs={"device": "cpu"},
        encode_kwargs={"normalize_embeddings": True},
    )


def create_and_save_vector_store(documents: list[Document]) -> FAISS:
    """Embed the chunks, build a FAISS index and persist it to disk."""
    os.makedirs(DB_DIR, exist_ok=True)
    store = FAISS.from_documents(documents, get_embeddings_model())
    store.save_local(FAISS_INDEX_PATH)
    return store


def load_vector_store() -> FAISS | None:
    """Load a previously saved index, or return None if there isn't one."""
    if not os.path.exists(FAISS_INDEX_PATH):
        return None
    # The index was written by this app, so pickle deserialization is safe here.
    return FAISS.load_local(
        FAISS_INDEX_PATH,
        get_embeddings_model(),
        allow_dangerous_deserialization=True,
    )


def clear_vector_store() -> None:
    """Delete the saved index from disk."""
    shutil.rmtree(FAISS_INDEX_PATH, ignore_errors=True)
